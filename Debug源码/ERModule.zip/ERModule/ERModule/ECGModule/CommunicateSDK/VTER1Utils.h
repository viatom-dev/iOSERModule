//
//  VTER1Utils.h
//  ERModule
//
//  Created by yangweichao on 2021/4/6.
//

#import "VTMURATUtils.h"
#import "VTMBLEParser.h"

NS_ASSUME_NONNULL_BEGIN

@interface VTER1Utils : VTMURATUtils

+ (instancetype)sharedInstance;

@end

NS_ASSUME_NONNULL_END
