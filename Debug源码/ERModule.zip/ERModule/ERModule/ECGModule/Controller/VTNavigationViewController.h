//
//  VTNavigationViewController.h
//  ERModule
//
//  Created by yangweichao on 2021/4/6.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface VTNavigationViewController : UINavigationController

@end

NS_ASSUME_NONNULL_END
