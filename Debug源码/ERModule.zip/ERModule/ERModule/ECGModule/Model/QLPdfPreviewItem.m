//
//  QLPdfPreviewItem.m
//  iwown
//
//  Created by viatom on 2020/6/5.
//  Copyright © 2020 LP. All rights reserved.
//

#import "QLPdfPreviewItem.h"

@implementation QLPdfPreviewItem

@end
