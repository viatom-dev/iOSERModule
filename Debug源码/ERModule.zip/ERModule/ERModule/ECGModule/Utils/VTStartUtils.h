//
//  VTStartUtils.h
//  ERModule
//
//  Created by yangweichao on 2021/4/6.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface VTStartUtils : NSObject

+ (void)startWithTarget:(UIViewController *)superViewController;

@end

NS_ASSUME_NONNULL_END
