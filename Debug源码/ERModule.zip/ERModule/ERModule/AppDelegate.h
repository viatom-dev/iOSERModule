//
//  AppDelegate.h
//  VTMProductSDK
//
//  Created by viatom on 2020/6/22.
//  Copyright © 2020 viatom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic, strong) UIWindow *window;

@end

